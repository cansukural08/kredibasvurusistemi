/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;


/**
 *CDİ - Context Dependency Injection
 * 
 * @author IS97302
 */
@Named
@SessionScoped
public class HelloBean implements Serializable{
 
    String Ad;
    String Soyad;
    int tel;
    int tc;
    int gelir;
    int krediLimit;
    int krc=4;
    int krediSkoru;
    
    public void setAd(String Ad) {
        this.Ad=Ad;       
    }
    public String getAd(){
        return Ad;
    }
    
      public void setSoyad(String Soyad) {
        this.Soyad=Soyad;       
    }
    public String getSoyad(){
        return Soyad;
    }
    
      public void setTel(int tel) {
        this.tel=tel;       
    }
    public int getTel(){
        return tel;
    }
    
    public void setTc(int tc) {
        this.tc=tc;       
    }
    public int getTc(){
        return tc;
    }
    
    public void setGelir(int gelir) {
        this.gelir=gelir;       
    }
    public int getGelir(){
        return gelir;
    }
    public void setKrediLimit(int krediLimit) {
        this.krediLimit=krediLimit;       
    }
    public int getKrediLimit(){
        return krediLimit;
    }
       public void setKrc(int krc) {
        this.krc=krc;       
    }
    public int getKrc(){
        return krc;
    }
    
    public void setKrediSkoru(int krediSkoru) {
        this.krediSkoru=krediSkoru;       
    }
    public int getKrediSkoru(){
        return krediSkoru;
    }


    public String sendTheInfo(){
                
        
               krediSkoru=gelir / 5;
              
            if (krediSkoru < 500) {
             return "fail";
            
            }
            else if(krediSkoru >=500 && krediSkoru<1000 && gelir<5000) {
                
                return "first";
                }
            else  {
                
                
              
                krediLimit=gelir * krc;
               
               
 }
            return "success";
    }           
}

